package principal;

import java.util.Date;

public class Pagamento {
	private int id_pagamento;
	private String status_pag;
	private Date data_pag;
	private double valor_pag;
	private String forma_pag;
	private int parcela;
	public Pagamento(int id_pagamento, String status_pag, Date data_pag, double valor_pag, String forma_pag,
			int parcela) {
		super();
		this.id_pagamento = id_pagamento;
		this.status_pag = status_pag;
		this.data_pag = data_pag;
		this.valor_pag = valor_pag;
		this.forma_pag = forma_pag;
		this.parcela = parcela;
	}
	
	public Pagamento() {
		
	}

	public int getId_pagamento() {
		return id_pagamento;
	}

	public void setId_pagamento(int id) {
		this.id_pagamento = id;
	}

	public String getStatus_pag() {
		return status_pag;
	}

	public void setStatus_pag(String status_pag) {
		this.status_pag = status_pag;
	}

	public Date getData_pag() {
		return data_pag;
	}

	public void setData_pag(Date data_pag) {
		this.data_pag = data_pag;
	}

	public double getValor_pag() {
		return valor_pag;
	}

	public void setValor_pag(double valor_pag) {
		this.valor_pag = valor_pag;
	}

	public String getForma_pag() {
		return forma_pag;
	}

	public void setForma_pag(String forma_pag) {
		this.forma_pag = forma_pag;
	}

	public int getParcela() {
		return parcela;
	}

	public void setParcela(int parcela) {
		this.parcela = parcela;
	}
	
	
	
}
