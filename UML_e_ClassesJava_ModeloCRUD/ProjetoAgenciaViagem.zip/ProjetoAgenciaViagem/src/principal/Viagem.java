package principal;

import java.util.Date;

public class Viagem {
	private int id_viagem;
	private String origem;
	private String destino;
	private Date data_ida;
	private Date data_volta;
	
	public Viagem(int id_viagem, String origem, String destino, Date data_ida, Date data_volta) {
		super();
		this.id_viagem = id_viagem;
		this.origem = origem;
		this.destino = destino;
		this.data_ida = data_ida;
		this.data_volta = data_volta;
	}

	public Viagem() {

	}

	public int getId_viagem() {
		return id_viagem;
	}

	public void setId_viagem(int id_viagem) {
		this.id_viagem = id_viagem;
	}

	public String getOrigem() {
		return origem;
	}

	public void setOrigem(String origem) {
		this.origem = origem;
	}

	public String getDestino() {
		return destino;
	}

	public void setDestino(String destino) {
		this.destino = destino;
	}

	public Date getData_ida() {
		return data_ida;
	}

	public void setData_ida(Date data_ida) {
		this.data_ida = data_ida;
	}

	public Date getData_volta() {
		return data_volta;
	}

	public void setData_volta(Date data_volta) {
		this.data_volta = data_volta;
	}
	
	
	
}
