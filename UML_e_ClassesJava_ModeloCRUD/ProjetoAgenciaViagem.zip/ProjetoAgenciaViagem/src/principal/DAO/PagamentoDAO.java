package principal.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import principal.Color;
import principal.Conexao;
import principal.Pagamento;

public class PagamentoDAO {
	private Connection conexao;

    public PagamentoDAO() {
        try {
            conexao = Conexao.conectar();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
	
    public void criarPagamento(Pagamento pagamento) {
		String sql = "INSERT INTO pagamento (status_pag, data_pag, valor_pag, forma_pag, parcela) VALUES (?, NOW(), ?, ?, ?)";
		try (PreparedStatement stmt = conexao.prepareStatement(sql)) {
			stmt.setString(1, pagamento.getStatus_pag());
			stmt.setDouble(2, pagamento.getValor_pag());
			stmt.setString(3, pagamento.getForma_pag());
			stmt.setInt(4, pagamento.getParcela());
			stmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
    
    public Pagamento buscarPagamento(int id) {
    	Pagamento pagamento = null;
        String sql = "SELECT * FROM pagamento WHERE id_pagamento = ?";
        try (PreparedStatement stmt = conexao.prepareStatement(sql)) {
            stmt.setInt(1, id);
            ResultSet resultado = stmt.executeQuery();
            if (resultado.next()) {
            	pagamento = new Pagamento();
            	pagamento.setId_pagamento(resultado.getInt("id_pagamento"));
            	pagamento.setStatus_pag(resultado.getString("status_pag"));
            	pagamento.setData_pag(resultado.getDate("data_pag"));
            	pagamento.setValor_pag(resultado.getDouble("valor_pag"));
            	pagamento.setForma_pag(resultado.getString("forma_pag"));
            	pagamento.setParcela(resultado.getInt("parcela"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return pagamento;
    }

	public void atualizarPagamento(Pagamento pagamento) {
		String sql = "UPDATE pagamento SET status_pag = ?, data_pag = ?, valor_pag = ?, forma_pag = ?, parcela = ? WHERE id_pagamento = ?";
		try (PreparedStatement stmt = conexao.prepareStatement(sql)) {
			
			stmt.setString(1, pagamento.getStatus_pag());
			stmt.setTimestamp(2, new java.sql.Timestamp(pagamento.getData_pag().getTime()));
			stmt.setDouble(3, pagamento.getValor_pag());
			stmt.setString(4, pagamento.getForma_pag());
			stmt.setInt(5, pagamento.getParcela());
			stmt.setInt(6, pagamento.getId_pagamento());
			stmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void excluirPagamento(int id) {
		String sql = "DELETE FROM pagamento WHERE id_pagamento = ?";
		try (PreparedStatement stmt = conexao.prepareStatement(sql)) {
			stmt.setInt(1, id);
			stmt.executeUpdate();
			System.out.println(Color.GREEN+"Pagamento excluído com sucesso!"+Color.RESET);
		} catch (SQLException e) {
			System.out.println(Color.RED+"\nERROR! Pagamento não excluído."+Color.RESET);
			System.out.println(Color.YELLOW+"Verifique a relação com uma reserva! ");
			System.out.println("Erro: " + e.getMessage()+Color.RESET);
		}
	}
	
	public List<Pagamento> listarPagamento() {
		List<Pagamento> pagamentos = new ArrayList<>();
		String sql = "SELECT * FROM pagamento";
		try (PreparedStatement stmt = conexao.prepareStatement(sql)) {
			ResultSet resultado = stmt.executeQuery();
			while (resultado.next()) {
				Pagamento pagamento = new Pagamento();
				pagamento.setId_pagamento(resultado.getInt("id_pagamento"));
            	pagamento.setStatus_pag(resultado.getString("status_pag"));
            	pagamento.setData_pag(resultado.getDate("data_pag"));
            	pagamento.setValor_pag(resultado.getDouble("valor_pag"));
            	pagamento.setForma_pag(resultado.getString("forma_pag"));
            	pagamento.setParcela(resultado.getInt("parcela"));
				pagamentos.add(pagamento);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return pagamentos;
	}
    
    public void fecharConexao() {
		try {
			if (conexao != null && !conexao.isClosed()) {
				conexao.close();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}
