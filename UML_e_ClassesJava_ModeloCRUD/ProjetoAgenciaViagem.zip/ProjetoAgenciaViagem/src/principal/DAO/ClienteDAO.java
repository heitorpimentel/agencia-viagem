package principal.DAO;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import principal.Conexao;
import principal.Cliente;
import principal.Color;

public class ClienteDAO {
	private Connection conexao;

    public ClienteDAO() {
        try {
            conexao = Conexao.conectar();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    public void criarCliente(Cliente cliente) {
		String sql = "INSERT INTO cliente (nome, sexo, data_nasc, cpf, email, senha, telefone) VALUES (?, ?, ?, ?, ?, ?, ?)";
		try (PreparedStatement stmt = conexao.prepareStatement(sql)) {
			stmt.setString(1, cliente.getNome());
			stmt.setString(2, cliente.getSexo());
			stmt.setDate(3, new Date(cliente.getData_nasc().getTime()));
			stmt.setString(4, cliente.getCpf());
			stmt.setString(5, cliente.getEmail());
			stmt.setString(6, cliente.getSenha());
			stmt.setString(7, cliente.getTelefone());
			stmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
    
    public Cliente buscarCliente(int id) {
    	Cliente cliente = null;
        String sql = "SELECT * FROM cliente WHERE id_cliente = ?";
        try (PreparedStatement stmt = conexao.prepareStatement(sql)) {
            stmt.setInt(1, id);
            ResultSet resultado = stmt.executeQuery();
            if (resultado.next()) {
                cliente = new Cliente();
                cliente.setId_cliente(resultado.getInt("id_cliente"));
                cliente.setNome(resultado.getString("nome"));
				cliente.setSexo(resultado.getString("sexo"));
				cliente.setData_nasc(resultado.getDate("data_nasc"));
				cliente.setCpf(resultado.getString("cpf"));
				cliente.setEmail(resultado.getString("email"));
				cliente.setSenha(resultado.getString("senha"));
				cliente.setTelefone(resultado.getString("telefone"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return cliente;
    }

	public void atualizarCliente(Cliente cliente) {
		String sql = "UPDATE cliente SET nome = ?, sexo = ?, data_nasc = ?, cpf = ?, email = ?, senha = ?, telefone = ? WHERE id_cliente = ?";
		try (PreparedStatement stmt = conexao.prepareStatement(sql)) {
			
			stmt.setString(1, cliente.getNome());
			stmt.setString(2, cliente.getSexo());
			stmt.setDate(3, new Date(cliente.getData_nasc().getTime()));
			stmt.setString(4, cliente.getCpf());
			stmt.setString(5, cliente.getEmail());
			stmt.setString(6, cliente.getSenha());
			stmt.setString(7, cliente.getTelefone());
			stmt.setInt(8, cliente.getId_cliente());
			stmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void excluirCliente(int id) {
		String sql = "DELETE FROM cliente WHERE id_cliente = ?";
		try (PreparedStatement stmt = conexao.prepareStatement(sql)) {
			stmt.setInt(1, id);
			stmt.executeUpdate();
			System.out.println(Color.GREEN+ "Cliente excluído com sucesso!"+Color.RESET);
		} catch (SQLException e) {
			System.out.println(Color.RED+"\nERROR! Cliente não excluído."+Color.RESET);
			System.out.println(Color.YELLOW+"Verifique se o cliente tem reserva! ");
			System.out.println("Erro: " + e.getMessage()+Color.RESET);			
		}
	}
	
	public List<Cliente> listarCliente() {
		List<Cliente> clientes = new ArrayList<>();
		String sql = "SELECT id_cliente, nome, sexo, data_nasc, cpf, email, CONCAT(REPEAT('*', LENGTH(senha))) AS senha, telefone FROM cliente";
		try (PreparedStatement stmt = conexao.prepareStatement(sql)) {
			ResultSet resultado = stmt.executeQuery();
			while (resultado.next()) {
				Cliente cliente = new Cliente();
				cliente.setId_cliente(resultado.getInt("id_cliente"));
				cliente.setNome(resultado.getString("nome"));
				cliente.setSexo(resultado.getString("sexo"));
				cliente.setData_nasc(resultado.getDate("data_nasc"));
				cliente.setCpf(resultado.getString("cpf"));
				cliente.setEmail(resultado.getString("email"));
				cliente.setSenha(resultado.getString("senha"));
				cliente.setTelefone(resultado.getString("telefone"));
				clientes.add(cliente);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return clientes;
	}
	
    public void fecharConexao() {
		try {
			if (conexao != null && !conexao.isClosed()) {
				conexao.close();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	    
}
