package principal.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import principal.Color;
import principal.Conexao;
import principal.Viagem;

public class ViagemDAO {
	private Connection conexao;

    public ViagemDAO() {
        try {
            conexao = Conexao.conectar();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    public void criarViagem(Viagem viagem) {
		String sql = "INSERT INTO viagem (origem, destino, data_ida) VALUES (?, ?, ?)";
		try (PreparedStatement stmt = conexao.prepareStatement(sql)) {
			stmt.setString(1, viagem.getOrigem());
			stmt.setString(2, viagem.getDestino());
			stmt.setTimestamp(3, new java.sql.Timestamp(viagem.getData_ida().getTime()));						
			stmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
    
    public void criarDataVolta(Viagem viagem) {
		String sql = "INSERT INTO viagem (data_volta) VALUES (?)";
		try (PreparedStatement stmt = conexao.prepareStatement(sql)) {
			stmt.setTimestamp(1, new java.sql.Timestamp(viagem.getData_volta().getTime()));			
			stmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
    
    public Viagem buscarViagem(int id) {
    	Viagem viagem = null;
        String sql = "SELECT * FROM viagem WHERE id_viagem = ?";
        try (PreparedStatement stmt = conexao.prepareStatement(sql)) {
            stmt.setInt(1, id);
            ResultSet resultado = stmt.executeQuery();
            if (resultado.next()) {
            	viagem = new Viagem();
            	viagem.setId_viagem(resultado.getInt("id_viagem"));
            	viagem.setOrigem(resultado.getString("origem"));
            	viagem.setDestino(resultado.getString("destino"));
            	viagem.setData_ida(resultado.getDate("data_ida"));
            	viagem.setData_volta(resultado.getDate("data_volta"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return viagem;
    }

	public void atualizarViagem(Viagem viagem) {
		String sql = "UPDATE viagem SET origem = ?, destino = ?, data_ida = ?, data_volta = ? WHERE id_viagem = ?";
		try (PreparedStatement stmt = conexao.prepareStatement(sql)) {			
			stmt.setString(1, viagem.getOrigem());
			stmt.setString(2, viagem.getDestino());
			stmt.setTimestamp(3, new java.sql.Timestamp(viagem.getData_ida().getTime()));
			stmt.setInt(4, viagem.getId_viagem());
			stmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public void atualizarDataVolta(Viagem viagem) {
		String sql = "UPDATE viagem SET data_volta = ? WHERE id_viagem = ?";
		try (PreparedStatement stmt = conexao.prepareStatement(sql)) {			
			stmt.setTimestamp(1, new java.sql.Timestamp(viagem.getData_volta().getTime()));
			stmt.setInt(2, viagem.getId_viagem());
			stmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void excluirViagem(int id) {
		String sql = "DELETE FROM viagem WHERE id_viagem = ?";
		try (PreparedStatement stmt = conexao.prepareStatement(sql)) {
			stmt.setInt(1, id);
			stmt.executeUpdate();
			System.out.println(Color.GREEN+ "Viagem excluída com sucesso!"+Color.RESET);
		} catch (SQLException e) {
			System.out.println(Color.RED+"\nERROR! Viagem não excluída."+Color.RESET);
			System.out.println(Color.YELLOW+"Há um reserva para esta viagem! ");
			System.out.println("Erro: " + e.getMessage()+Color.RESET);		
		}
	}
	
	public List<Viagem> listarViagem() {
		List<Viagem> viagens = new ArrayList<>();
		String sql = "SELECT * FROM viagem";
		try (PreparedStatement stmt = conexao.prepareStatement(sql)) {
			ResultSet resultado = stmt.executeQuery();
			while (resultado.next()) {
				Viagem viagem = new Viagem();
				viagem.setId_viagem(resultado.getInt("id_viagem"));
            	viagem.setOrigem(resultado.getString("origem"));
            	viagem.setDestino(resultado.getString("destino"));
            	viagem.setData_ida(resultado.getDate("data_ida"));
            	viagem.setData_volta(resultado.getDate("data_volta"));
				viagens.add(viagem);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return viagens;
	}
    
    public void fecharConexao() {
		try {
			if (conexao != null && !conexao.isClosed()) {
				conexao.close();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
}
