package principal;

import java.time.LocalDate;
import java.util.Date;

public class Reserva {
	private Cliente cliente;
	private Viagem viagem;
	private Pagamento pagamento;
	private int id_reserva;
	private Date data_reserva;
	private String status_reserva;
		
	private LocalDate dataAtual;

    public LocalDate getDataAtual() {
        dataAtual = LocalDate.now(); // Isso define a data atual sempre que o método é chamado.
        return dataAtual;
    }
	
	public Reserva(Cliente cliente, Viagem viagem, Pagamento pagamento, int id_reserva, Date data_reserva,
			String status_reserva) {
		super();
		this.cliente = cliente;
		this.viagem = viagem;
		this.pagamento = pagamento;
		this.id_reserva = id_reserva;
		this.data_reserva = data_reserva;
		this.status_reserva = status_reserva;		
	}

	public Reserva() {
		
	}
	
	public Cliente getCliente() {
		return cliente;
	}

	public void setCliente(Cliente cliente) {
		this.cliente = cliente;
	}

	public Viagem getViagem() {
		return viagem;
	}

	public void setViagem(Viagem viagem) {
		this.viagem = viagem;
	}

	public Pagamento getPagamento() {
		return pagamento;
	}

	public void setPagamento(Pagamento pagamento) {
		this.pagamento = pagamento;
	}

	public int getId_reserva() {
		return id_reserva;
	}

	public void setId_reserva(int id_reserva) {
		this.id_reserva = id_reserva;
	}

	public Date getData_reserva() {
		return data_reserva;
	}

	public void setData_reserva(Date data_reserva) {
		this.data_reserva = data_reserva;
	}

	public String getStatus_reserva() {
		return status_reserva;
	}

	public void setStatus_reserva(String status_reserva) {
		this.status_reserva = status_reserva;
	}
	
	
	
}
