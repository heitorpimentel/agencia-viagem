package principal;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

import principal.DAO.ClienteDAO;
import principal.DAO.ViagemDAO;
import principal.DAO.PagamentoDAO;
import principal.DAO.ReservaDAO;

public class Main {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		ClienteDAO clienteDAO = new ClienteDAO();
		ViagemDAO viagemDAO = new ViagemDAO();
		PagamentoDAO pagamentoDAO = new PagamentoDAO();
		ReservaDAO reservaDAO = new ReservaDAO();
		
		while (true) {
            System.out.println(Color.CYAN+"\nSistema de Gestão da HP Viagens"+Color.RESET);
            System.out.println("1. Gestão de Cliente");
            System.out.println("2. Gestão de Viagens");
            System.out.println("3. Gestão de Pagamentos");
            System.out.println("4. Gestão das Reservas");
            System.out.println("0. Sair");
            System.out.print("Escolha uma opção: ");
            
            int opcao = scanner.nextInt();
            switch (opcao) {
            	
            	case 1:
            		do {
            			System.out.println(Color.CYAN+"\nÁrea de gestão dos CLientes"+Color.RESET);
                        System.out.println("1. Cadastrar Cliente");
                        System.out.println("2. Listar Cliente");
                        System.out.println("3. Atualilzar Cliente");
                        System.out.println("4. Excluir Cliente");
                        System.out.println("5. Voltar para menu principal");
                        System.out.print("Escolha uma opção: ");
            			int opcao1 = scanner.nextInt();
            			
            			switch (opcao1) {
            			case 1:
            				Cliente criarCliente = new Cliente();
            				System.out.print("Nome completo: ");
        		            scanner.nextLine(); // Limpar o buffer do teclado
        		            criarCliente.setNome(scanner.nextLine());
        		            System.out.print("Sexo: ");            
        		            criarCliente.setSexo(scanner.nextLine());
        		            System.out.print("Data de nascimento (dd/mm/yyyy): ");            
        		            try {
        		            	String DataString = scanner.next();
        		                SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        		                Date DataNasc = sdf.parse(DataString);
        		                criarCliente.setData_nasc(DataNasc);        		                
        		            } catch (ParseException e) {
        		                System.out.println(Color.RED+"Formato de data inválido. Use dd/mm/yyyy."+Color.RESET);
        		            }
        		            System.out.print("CPF (somente números): ");  
        		            scanner.nextLine();
        		            criarCliente.setCpf(scanner.nextLine());
        		            System.out.print("Email: ");            
        		            criarCliente.setEmail(scanner.nextLine());
        		            System.out.print("Senha: ");            
        		            criarCliente.setSenha(scanner.nextLine());
        		            System.out.println("Número de telefone: ");
        		            criarCliente.setTelefone(scanner.nextLine());
        		            clienteDAO.criarCliente(criarCliente);
        		            System.out.println(Color.GREEN+"Cliente cadastrado com sucesso!"+Color.RESET);
            				break;
            			case 2:
            				System.out.println("Clientes: ");
            				List<Cliente> cliente = null;
            				try {
            					cliente = clienteDAO.listarCliente();
            				} catch (Exception e) {
            					e.printStackTrace();
            				}
            				for (Cliente clientes : cliente) {
            					System.out.println("ID:" + clientes.getId_cliente() + ", Nome: " + clientes.getNome() +
            							", Sexo: " + clientes.getSexo() + ", Data de Nascimento: " + clientes.getData_nasc() +
            							", CPF: " + clientes.getCpf() + ", Email: - " + clientes.getEmail() +
            							", Senha: " + clientes.getSenha() + ", Telefone: " + clientes.getTelefone());
            				}
            				break;
            			case 3:
            				System.out.print("ID do cliente para atualização: ");
            		        int clienteId = scanner.nextInt();
            		        Cliente clienteAtualizar = clienteDAO.buscarCliente(clienteId);
            		        
            		        if (clienteAtualizar != null) {
            		        	System.out.print("Novo Nome do cliente: ");
            		            scanner.nextLine(); // Limpar o buffer do teclado
            		            clienteAtualizar.setNome(scanner.nextLine());
            		            System.out.print("Novo sexo do cliente: ");            
            		            clienteAtualizar.setSexo(scanner.nextLine());
            		            System.out.print("Nova Data de nascimento (dd/mm/yyyy): ");            
            		            try {
            		            	String novaDataString = scanner.next();
            		                SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
            		                Date novaDataNasc = sdf.parse(novaDataString);
            		                clienteAtualizar.setData_nasc(novaDataNasc);
            		                
            		            } catch (ParseException e) {
            		                System.out.println(Color.RED+"Formato de data inválido. Use dd/mm/yyyy."+Color.RESET);
            		            }
            		            System.out.print("Novo CPF (somente números): ");  
            		            scanner.nextLine();
            		            clienteAtualizar.setCpf(scanner.nextLine());
            		            System.out.print("Novo email: ");            
            		            clienteAtualizar.setEmail(scanner.nextLine());
            		            System.out.print("Nova senha: ");            
            		            clienteAtualizar.setSenha(scanner.nextLine());
            		            System.out.println("Novo número de telefone: ");
            		            clienteAtualizar.setTelefone(scanner.nextLine());
            		            clienteDAO.atualizarCliente(clienteAtualizar);
            		            System.out.println(Color.GREEN+"Cliente atualizado com sucesso!"+Color.RESET);
            		            
            		        } else {
            		            System.out.println("Dados não encontrados.");
            		        }
            				break;
            			case 4:
            				System.out.print("ID do Cliente para exclusão: ");
            		        int clienteIdExcluir = scanner.nextInt();            		        
            		        Cliente clienteExcluir = clienteDAO.buscarCliente(clienteIdExcluir);            		        
            		           if(clienteExcluir != null) {
	            		            System.out.println("Cliente " + clienteExcluir.getNome() + " encontrado");		            		             
	            		            System.out.println("Deseja excluir? 1 -SIM, 0 -NÃO : ");	            		            
	            		            int verificar = scanner.nextInt();
	            		            if (verificar != 0) {	            		                
	            		                    clienteDAO.excluirCliente(clienteIdExcluir);	            		                    	            		                
	            		            } else {
	            		            		System.out.println("Voltando para menu...");
	            		            } 
	            		        
	            		       } else {
	            		        		System.out.println("Cliente não encontrado.");
	            		        		System.out.println("Voltando para menu...");
	            		       }
            				break;
            			case 5:
            				System.out.println("Voltando para menu principal");
            				break;
            			default:
            				System.out.println("Opção inválida. Tente novamente.");
            				break;            			
            			}
            		} while(opcao == 5);
            		break;
            	case 2:
            		do {
            			System.out.println(Color.CYAN+"\nÁrea de gestão das Viagens"+Color.RESET);
                        System.out.println("1. Cadastrar Viagem");
                        System.out.println("2. Listar Viagens");
                        System.out.println("3. Atualilzar Viagem");
                        System.out.println("4. Excluir Viagem");
                        System.out.println("5. Voltar para menu principal");
                        System.out.print("Escolha uma opção: ");
            			int opcao1 = scanner.nextInt();
            			
            			switch (opcao1) {
            			case 1:
            				Viagem criarViagem = new Viagem();
            				System.out.print("Qual a origem da viagem: ");
        		            scanner.nextLine(); // Limpar o buffer do teclado
        		            criarViagem.setOrigem(scanner.nextLine());
        		            System.out.print("Qual o destino da viagem: ");            
        		            criarViagem.setDestino(scanner.nextLine());
        		            System.out.print("Data de ida (dd/mm/yyyy): ");            
        		            try {
        		            	String DataString = scanner.next();
        		                SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        		                Date DataViagem = sdf.parse(DataString);
        		                criarViagem.setData_ida(DataViagem);        		                
        		            } catch (ParseException e) {
        		                System.out.println(Color.RED+"Formato de data inválido. Use dd/mm/yyyy."+Color.RESET);
        		            }
        		            System.out.println("Deseja marcar a data de volta? 1.SIM   2.NÃO");
        		            int volta = scanner.nextInt();
        		            if(volta == 1) {
	        		            System.out.print("Data de volta (dd/mm/yyyy): ");            
	        		            try {
	        		            	String DataString = scanner.next();
	        		                SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
	        		                Date DataViagem = sdf.parse(DataString);
	        		                criarViagem.setData_volta(DataViagem);
	        		                viagemDAO.criarDataVolta(criarViagem);
	        		                viagemDAO.criarViagem(criarViagem);
	        		                System.out.println(Color.GREEN+"Viagem cadastrada com sucesso!"+Color.RESET);
	        		            } catch (ParseException e) {
	        		                System.out.println(Color.RED+"Formato de data inválido. Use dd/mm/yyyy."+Color.RESET);
	        		            }
        		            } else {
        		            	viagemDAO.criarViagem(criarViagem);
        		            	System.out.println(Color.GREEN+"Viagem cadastrada com sucesso!"+Color.RESET);
        		            }
        		            
            				break;
            			case 2:
            				System.out.println("Viagens: ");
            				List<Viagem> viagem = null;
            				try {
            					viagem = viagemDAO.listarViagem();
            				} catch (Exception e) {
            					e.printStackTrace();
            				}
            				for (Viagem viagens : viagem) {
            					System.out.println("ID: " + viagens.getId_viagem() +
            							", Origem: " + viagens.getOrigem() + ", Destino: " + viagens.getDestino() +
            							", Data de ida: " + viagens.getData_ida() + ", Data de volta: " + viagens.getData_volta());
            				}
            				break;
            			case 3:
            				System.out.print("ID do viagem para atualização: ");
            		        int viagemId = scanner.nextInt();
            		        Viagem viagemAtualizar = viagemDAO.buscarViagem(viagemId);
            		        
            		        if (viagemAtualizar != null) {
            		        	System.out.print("Qual a nova origem da viagem: ");
            		            scanner.nextLine(); // Limpar o buffer do teclado
            		            viagemAtualizar.setOrigem(scanner.nextLine());
            		            System.out.print("Qual o novo destino da viagem: ");            
            		            viagemAtualizar.setDestino(scanner.nextLine());
            		            System.out.print("Nova data de ida (dd/mm/yyyy): ");            
            		            try {
            		            	String DataString = scanner.next();
            		                SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
            		                Date DataViagem = sdf.parse(DataString);
            		                viagemAtualizar.setData_ida(DataViagem);        		                
            		            } catch (ParseException e) {
            		                System.out.println(Color.RED+"Formato de data inválido. Use dd/mm/yyyy."+Color.RESET);
            		            }
            		            System.out.println("Deseja marcar a data de volta ou alterá-la? 1.SIM   2.NÃO");
            		            int volta2 = scanner.nextInt();
            		            if(volta2 == 1) {
	            		            System.out.print("Data de volta (dd/mm/yyyy): ");            
	            		            try {
	            		            	String DataString = scanner.next();            		            	
	        		            		viagemAtualizar.setData_volta(null);            		            	
	            		                SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
	            		                Date DataViagem = sdf.parse(DataString);
	            		                viagemAtualizar.setData_volta(DataViagem);
	            		                viagemDAO.atualizarDataVolta(viagemAtualizar);
	            		                viagemDAO.atualizarViagem(viagemAtualizar);
	                		            System.out.println(Color.GREEN+"Viagem atualizada com sucesso!"+Color.RESET);
	            		            } catch (ParseException e) {
	            		                System.out.println(Color.RED+"Formato de data inválido. Use dd/mm/yyyy."+Color.RESET);
	            		            }
            		            } else {            		            	
            		            	viagemDAO.atualizarViagem(viagemAtualizar);
                		            System.out.println(Color.GREEN+"Viagem atualizada com sucesso!"+Color.RESET);
            		            }
            		            
            		            
            		        } else {
            		            System.out.println("Dados não encontrados.");
            		        }
            				break;
            			case 4:
            				System.out.print("ID da viagem para exclusão: ");
            		        int viagemIdExcluir = scanner.nextInt();            		                    		        
            		        Viagem consulta = viagemDAO.buscarViagem(viagemIdExcluir);            		        
            		        if(consulta != null) {
            		            System.out.println("Viagem para " + consulta.getDestino());            		            
			            		System.out.println("Deseja excluir? 1 -SIM, 0 -NÃO : ");
            		            int verificar = scanner.nextInt();
            		            if (verificar != 0) {
            		            	viagemDAO.excluirViagem(viagemIdExcluir);      		                    
            		            }  
        		            } else {
        		        		System.out.println("Viagem não encontrado.");
        		        		System.out.println("Voltando para menu...");
        		        	}
            				break;
            			case 5:
            				System.out.println("Voltando para menu principal");
            				break;
            			default:
            				System.out.println("Opção inválida. Tente novamente.");
            				break;            			
            			}
            		} while(opcao == 5);
            		break;
            	case 3:
            		do {
            			System.out.println(Color.GREEN+"\nÁrea de gestão dos Pagamentos"+Color.RESET);
                        System.out.println("1. Adicionar Pagamento");
                        System.out.println("2. Listar Pagamentos");
                        System.out.println("3. Atualilzar dados Pagamento");
                        System.out.println("4. Excluir Pagamento");
                        System.out.println("5. Voltar para menu principal");
                        System.out.print("Escolha uma opção: ");
            			int opcao2 = scanner.nextInt();
            			
            			switch (opcao2) {
            			case 1:
            				Pagamento criarPagamento = new Pagamento();
        		            System.out.print("Status (1. Pago   2. Pendente): ");
        		            int status = scanner.nextInt();
        		            
        		            if (status == 1) {
        		            	criarPagamento.setStatus_pag("Pago");
        		            } else if(status == 2) {
        		            	criarPagamento.setStatus_pag("Pendente");
        		            } else {
        		            	System.out.println(Color.RED+"Escolha uma opção válida!"+Color.RESET);
        		            	criarPagamento.setStatus_pag(null);
        		            }
        		            
        		            System.out.print("Data do Pagamento (dd/mm/yyyy): ");            
        		            try {
        		            	String DataString = scanner.next();
        		                SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        		                Date DataPag = sdf.parse(DataString);
        		                criarPagamento.setData_pag(DataPag);        		                
        		            } catch (ParseException e) {
        		                System.out.println(Color.RED+"Formato de data inválido. Use dd/mm/yyyy."+Color.RESET);
        		            }
        		            System.out.print("Valor do Pagamento (somente números): R$"+Color.GREEN);  
        		            
        		            criarPagamento.setValor_pag(scanner.nextDouble());
        		            System.out.print(Color.RESET+"Forma de Pagamento: ");
        		            scanner.nextLine();
        		            criarPagamento.setForma_pag(scanner.nextLine());
        		            System.out.print("Quantidade de parcelas: ");            
        		            criarPagamento.setParcela(scanner.nextInt());
        		            pagamentoDAO.criarPagamento(criarPagamento);
        		            System.out.println(Color.GREEN+"Pagamento cadastrado com sucesso!"+Color.RESET);
            				break;
            			case 2:
            				System.out.println("Pagamentos: ");
            				List<Pagamento> pagamento = null;
            				try {
            					pagamento = pagamentoDAO.listarPagamento();
            				} catch (Exception e) {
            					e.printStackTrace();
            				}
            				for (Pagamento pagamentos : pagamento) {
            				    System.out.println("ID:" + pagamentos.getId_pagamento() + ", Status: " + pagamentos.getStatus_pag() +
            				    		            ", Data do pagamento: " + pagamentos.getData_pag() +
            				    		            ", Valor do pagamento: R$" + pagamentos.getValor_pag() +
            				    		            ", Forma de Pagamento: " + pagamentos.getForma_pag() +
            				    		            ", Parcelas: " + pagamentos.getParcela());
            				}
            				break;
            			case 3:
            				System.out.print("ID do pagamento para atualização: ");
            		        int pagamentoId = scanner.nextInt();
            		        Pagamento pagamentoAtualizar = pagamentoDAO.buscarPagamento(pagamentoId);
            		        
            		        if (pagamentoAtualizar != null) {
            		        	System.out.print("Novo status do pagamento: 1. Pago   2. Pendente ");
            		        	int status2 = scanner.nextInt();
            		        
	        		            if (status2 == 1) {
	        		            	pagamentoAtualizar.setStatus_pag("Pago");
	        		            } else if(status2 == 2) {
	        		            	pagamentoAtualizar.setStatus_pag("Pendente");
	        		            } else {
	        		            	System.out.println(Color.YELLOW+"Escolha uma opção válida! Status não atualizado."+Color.RESET);
	        		            	pagamentoAtualizar.setStatus_pag(pagamentoDAO.buscarPagamento(pagamentoId).getStatus_pag());
	        		            }
    	        		            
            		            System.out.print("Nova data de pagamento (dd/mm/yyyy): ");            
            		            try {
            		            	String novaDataString = scanner.next();
            		                SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
            		                Date novaDataPag = sdf.parse(novaDataString);
            		                pagamentoAtualizar.setData_pag(novaDataPag);
            		                
            		            } catch (ParseException e) {
            		                System.out.println(Color.RED+"Formato de data inválido. Use dd/mm/yyyy."+Color.RESET);
            		            }
            		            System.out.print("Valor do Pagamento (somente números): R$"+Color.GREEN);  
            		            pagamentoAtualizar.setValor_pag(scanner.nextDouble());
            		            System.out.print(Color.RESET+"Forma de Pagamento: ");
            		            scanner.nextLine();
            		            pagamentoAtualizar.setForma_pag(scanner.next());
            		            System.out.print("Quantidade de parcelas: ");            
            		            pagamentoAtualizar.setParcela(scanner.nextInt());
            		            scanner.nextLine();
            		            pagamentoDAO.atualizarPagamento(pagamentoAtualizar);
            		            System.out.println(Color.GREEN+"Pagamento atualizado com sucesso!"+Color.RESET);
            		            
            		        } else {
            		            System.out.println("Dados não encontrados.");
            		        }
            				break;
            			case 4:
            				System.out.print("ID do pagamento para exclusão: ");
            		        int pagamentoIdExcluir = scanner.nextInt();
            		                    		        
            		        Pagamento pagamentoExcluir = pagamentoDAO.buscarPagamento(pagamentoIdExcluir);
            		        if(pagamentoExcluir != null) {
            		            System.out.println("Pagamento no valor de: R$" + pagamentoExcluir.getValor_pag());                		                       		         
            		            	System.out.println("Deseja excluir o pagamento? 1 -SIM, 0 -NÃO : ");
	            		            int verificar = scanner.nextInt();
	            		            if (verificar != 0) {	            		                
	            		                    pagamentoDAO.excluirPagamento(pagamentoIdExcluir);	            		                
            		            	} else {
            		            		System.out.println("Voltando para menu...");
            		            	}            		            
        		            } else {
        		        		System.out.println("Pagamento não encontrado.");
        		        		System.out.println("Voltando para menu...");
        		        	}            		        
            				break;
            			case 5:
            				System.out.println("Voltando para menu principal");
            				break;
            			default:
            				System.out.println("Opção inválida. Tente novamente.");
            				break;            			
            			}
            		} while(opcao == 5);
            		break;
            	case 4:
            		do {
            			System.out.println(Color.CYAN+"\nÁrea de gestão das Reservas"+Color.RESET);
                        System.out.println("1. Cadastrar Reserva");
                        System.out.println("2. Listar Reservas");
                        System.out.println("3. Atualilzar Reserva");
                        System.out.println("4. Excluir Reserva");
                        System.out.println("5. Voltar para menu principal");
                        System.out.print("Escolha uma opção: ");
            			int opcao1 = scanner.nextInt();
            			
            			switch (opcao1) {
            			case 1:
            				Reserva reserva = new Reserva();
            				System.out.println("Digite o ID do cliente que vai viajar: ");
            				int clienteId = scanner.nextInt();
            				Cliente reservaCliente = clienteDAO.buscarCliente(clienteId);            				
            				if(reservaCliente != null) {
            					System.out.println("Cliente " + reservaCliente.getNome() + " encontrado!");
            					reserva.setCliente(reservaCliente);

            					System.out.println("Digite o ID da viagem: ");
            					int viagemId = scanner.nextInt();
                				Viagem reservaViagem = viagemDAO.buscarViagem(viagemId);
            					if (reservaViagem != null) {
            						reserva.setViagem(reservaViagem);
            						System.out.println("Viagem saindo de " + reservaViagem.getOrigem() +
            								" e indo para "+ reservaViagem.getDestino() + " encontrado!" + " Com data de ida: " +
            								reservaViagem.getData_ida() + " e volta: " +reservaViagem.getData_volta());
            						
            						System.out.println("Digite o ID do pagamento: ");
            						int pagamentoId = scanner.nextInt();
                    				Pagamento reservaPag = pagamentoDAO.buscarPagamento(pagamentoId);
            						if(reservaPag != null) {
            							reserva.setPagamento(reservaPag);
            							System.out.println("Pagamento com situação: " + reservaPag.getStatus_pag() +
                								" no valor de R$"+ reservaPag.getValor_pag() + " encontrado!" + " Com data: " +
                								reservaPag.getData_pag() + " Forma de pagamento: " +reservaPag.getForma_pag() + 
                								" em " + reservaPag.getParcela() + "x");
            							String statusPag = reservaDAO.buscarReserva(pagamentoId).getPagamento().getStatus_pag();
            							if(statusPag.equals("Pago") ) {            					
                    						reserva.setStatus_reserva(Color.GREEN+"Confirmada"+Color.RESET);                    						
                    					} else if(statusPag.equals("Pendente")) {
                    						reserva.setStatus_reserva(Color.YELLOW+"Pendente"+Color.RESET);
                    					}
            							reservaDAO.criarReserva(reserva);
            							System.out.println(Color.GREEN+"Reserva cadastrada com sucesso!"+Color.RESET);
                    		            System.out.print("Reserva realizada em: "+Color.CYAN + reserva.getDataAtual()+Color.RESET);
                    		            
            							} else {
            								System.out.println("Pagamento não encontrado. Cadastre um pagamento!");
            							}
                    				
            						} else {
            							System.out.println("Viagem não encontrada. Cadastre uma viagem!");
            						}
            					
            		            } else {
            					System.out.println("Cliente não encontrado. Cadastre um cliente!");
            				}
        		                    		          
            				break;
            			case 2:            				
            				List<Reserva> reservas = reservaDAO.listarReserva();
            				System.out.println("Reservas: ");
            				for (Reserva r : reservas) {
            					System.out.println("ID: " + r.getId_reserva() +
            							", Data da reserva: " + r.getData_reserva() +
            							", Status: " + r.getStatus_reserva() +
            							", Nome: " + r.getCliente().getNome() +
            							", Origem: " + r.getViagem().getOrigem() +
            							", Destino: " + r.getViagem().getDestino() +
            							", Data de ida: " + r.getViagem().getData_ida() +
            							", Data de volta: " + r.getViagem().getData_volta() +
            							", Valor: R$" + r.getPagamento().getValor_pag() +
            							", Situação: " + r.getPagamento().getStatus_pag());
            				}
            				break;
            			case 3:            				           				
            				System.out.print("ID do reserva para atualização: ");
            		        int reservaId = scanner.nextInt();
            		        Reserva reservaAtualizar = reservaDAO.buscarReserva(reservaId);            		        
            		        if (reservaAtualizar != null) {
            		        	
            		        	System.out.println("Atualizar status da reserva: ");
            					scanner.nextLine();
            					reservaAtualizar.setStatus_reserva(scanner.nextLine());
                				System.out.println("Digite o novo ID do cliente que vai viajar: ");
                				int atualizarClienteId = scanner.nextInt();
                				Cliente atualizarReservaCliente = clienteDAO.buscarCliente(atualizarClienteId);
                				if(atualizarReservaCliente != null) {
                					System.out.println("Cliente " + atualizarReservaCliente.getNome() + " encontrado!");
                					reservaAtualizar.setCliente(atualizarReservaCliente);

                					System.out.println("Digite o novo ID da viagem: ");
                					int viagemIdAtualizar = scanner.nextInt();
                    				Viagem atualizarReservaViagem = viagemDAO.buscarViagem(viagemIdAtualizar);
                					if (atualizarReservaViagem != null) {
                						reservaAtualizar.setViagem(atualizarReservaViagem);
                						System.out.println("Viagem saindo de " + atualizarReservaViagem.getOrigem() +
                								" e indo para "+ atualizarReservaViagem.getDestino() + " encontrado!" + " Com data de ida: " +
                								atualizarReservaViagem.getData_ida() + " e volta: " +atualizarReservaViagem.getData_volta());
                						
                						System.out.println("Digite o novo ID do pagamento: ");
                						int pagamentoIdAtualizar = scanner.nextInt();
                        				Pagamento reservaPagAtualizar = pagamentoDAO.buscarPagamento(pagamentoIdAtualizar);
                						if(reservaPagAtualizar != null) {
                							reservaAtualizar.setPagamento(reservaPagAtualizar);
                							System.out.println("Pagamento na situação: " + reservaPagAtualizar.getStatus_pag() +
                    								" no valor de R$"+ reservaPagAtualizar.getValor_pag() + " encontrado!" + " Com data: " +
                    								reservaPagAtualizar.getData_pag() + " Forma de pagamento: " +reservaPagAtualizar.getForma_pag() + 
                    								" em " + reservaPagAtualizar.getParcela() + "x");
                							String statusPag = reservaDAO.buscarReserva(pagamentoIdAtualizar).getPagamento().getStatus_pag();
                							if(statusPag.equals("Pago") ) {            					
                        						reservaAtualizar.setStatus_reserva(Color.GREEN+"Confirmada"+Color.RESET);                    						
                        					} else if(statusPag.equals("Pendente")) {
                        						reservaAtualizar.setStatus_reserva(Color.YELLOW+"Pendente"+Color.RESET);
                        					}      							
                							reservaDAO.atualizarReserva(reservaAtualizar);
                							System.out.println(Color.GREEN+"Reserva alterada com sucesso!"+Color.RESET);
                        		            System.out.print("Reserva alterada em: " + reservaAtualizar.getDataAtual());
                        		            
                							} else {
                								System.out.println("Pagamento não encontrado. Cadastre um pagamento!");
                							}
                        				
                						} else {
                							System.out.println("Viagem não encontrada. Cadastre uma viagem!");
                						}                					
                		            } else {
                		            	System.out.println("Dados não encontrados.");
                		            }
            		        }
            				break;
            			case 4:
            				System.out.print("ID da reserva para exclusão: ");
            		        int reservaIdExcluir = scanner.nextInt();
            		        
            		        Reserva reservaExcluir = reservaDAO.buscarReserva(reservaIdExcluir);
            		        if(reservaExcluir != null) {
            		            System.out.println("Reserva para " + reservaExcluir.getViagem().getDestino() +
            		            		" no nome de: " + reservaExcluir.getCliente().getNome());
            		            System.out.println("Deseja excluir? 1 -SIM, 0 -NÃO : ");
            		            int verificar = scanner.nextInt();
            		            	if (verificar != 0) {            		                
            		                    reservaDAO.excluirReserva(reservaIdExcluir);
            		                    System.out.println(Color.GREEN+"Reserva excluída com sucesso!"+Color.RESET);
            		                    System.out.println("Voltando para menu...");            		                
            		            	}	
            		            } else {
            		        		System.out.println("Reserva não encontrada.");
            		        		System.out.println("Voltando para menu...");
            		        	}
            				break;
            			case 5:
            				System.out.println("Voltando para menu principal");
            				break;
            			default:
            				System.out.println("Opção inválida. Tente novamente.");
            				break;         			
            			}
            		} while(opcao == 5);
            		break;            		
            	case 0:
            		System.out.println("Saindo do sistema...");
                    clienteDAO.fecharConexao();
            		viagemDAO.fecharConexao();
                    pagamentoDAO.fecharConexao();
                    reservaDAO.fecharConexao();
                    scanner.close();
                    System.exit(0);
            		break;
            	default:
            		System.out.println("Opção inválida. Tente novamente.");
            		break;
            }
            
		}
		
	}

}
